﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace THICUOIKI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
/*            DataTable dt = new DataTable();
            dataGridView1.DataSource = dt;*/
        }
        private void set_data_1(string SM, string TI, string TO, string TU, string TT)
        {
            dataGridView1.Rows.Add("0", SM, TI, TO, TU, "50000đ / giờ", TT);
            /*            DataTable dt = new DataTable();
                        DataRow row = dt.NewRow();
                        row["Column_STT"] = "0";
                        row["Column_SoMay"] = SM;
                        row["Column_TI"] = TI;
                        row["Column_TO"] = TO;
                        row["Column_TU"] = TU;
                        row["Column_DG"] = "50000đ / giờ";
                        row["Column_TT"] = TT;
                        dt.Rows.Add(row);
                        dataGridView1.DataSource = dt;*/
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (button_b1.BackColor == Color.Red)
            {
                MessageBox.Show("Máy tính bàn 1 đang được sử dụng, vui lòng chọn bàn khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                button_b1.BackColor = Color.Red;
                textBox_TI1.Enabled = true;
                textBox_TO1.Enabled = true;
                MessageBox.Show("Máy tính bàn 1 đã được bật", "Thông báo");
            }
        }
        private void button_tt1_Click(object sender, EventArgs e)
        {
            if (button_b1.BackColor == Color.Red)
            {
                int flag1 = 0;
                int flag2 = 0;
                if (int.TryParse(textBox_TI1.Text, out flag1) && int.TryParse(textBox_TO1.Text, out flag2))
                {
                    if (flag2 - flag1 > 0)
                    {
                        set_data_1(button_b1.Text,textBox_TI1.Text, textBox_TO1.Text,(flag2-flag1).ToString(), textBox_TT1.Text);
                        button_b1.BackColor = Color.LightGreen;
                        textBox_TT1.Clear();
                        textBox_TO1.Clear();
                        textBox_TI1.Enabled = false;
                        textBox_TO1.Enabled = false;
                        MessageBox.Show("Máy tính bàn 1 đã được thanh toán", "Thông báo");
                    }
                    else
                    {
                        MessageBox.Show("Vui lòng nhập đúng thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Vui lòng nhập đúng thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Hãy mở bàn!", "Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
        }

        private void textBox_TO1_TextChanged(object sender, EventArgs e)
        {
            int flag1 = 0;
            int flag2 = 0;
            if (int.TryParse(textBox_TI1.Text, out flag1) && int.TryParse(textBox_TO1.Text, out flag2))
            {
                if (flag2 - flag1 > 0)
                {
                    textBox_TT1.Text = Convert.ToString((flag2 - flag1) * 50000);
                }
            }
        }

        private void textBox_TI1_TextChanged(object sender, EventArgs e)
        {
            int flag1 = 0;
            int flag2 = 0;
            if (int.TryParse(textBox_TI1.Text, out flag1) && int.TryParse(textBox_TO1.Text, out flag2))
            {
                if (flag2 - flag1 > 0)
                {
                    textBox_TT1.Text = Convert.ToString((flag2 - flag1) * 50000);
                }
            }
        }

        private void button_b2_Click(object sender, EventArgs e)
        {
            if (button_b2.BackColor == Color.Red)
            {
                MessageBox.Show("Máy tính bàn 2 đang được sử dụng, vui lòng chọn bàn khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                button_b2.BackColor = Color.Red;
                textBox_TI2.Enabled = true;
                textBox_TO2.Enabled = true;
                MessageBox.Show("Máy tính bàn 2 đã được bật", "Thông báo");
            }
        }

        private void button_tt2_Click(object sender, EventArgs e)
        {
            if (button_b2.BackColor == Color.Red)
            {
                int flag1 = 0;
                int flag2 = 0;
                if (int.TryParse(textBox_TI2.Text, out flag1) && int.TryParse(textBox_TO2.Text, out flag2))
                {
                    if (flag2 - flag1 > 0)
                    {
                        set_data_1(button_b2.Text, textBox_TI2.Text, textBox_TO2.Text, (flag2 - flag1).ToString(), textBox_TT2.Text);
                        button_b2.BackColor = Color.LightGreen;
                        textBox_TT2.Clear();
                        textBox_TO2.Clear();
                        textBox_TI2.Enabled = false;
                        textBox_TO2.Enabled = false;
                        MessageBox.Show("Máy tính bàn 2 đã được thanh toán", "Thông báo");
                    }
                    else
                    {
                        MessageBox.Show("Vui lòng nhập đúng thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Vui lòng nhập đúng thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Hãy mở bàn!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void textBox_TO2_TextChanged(object sender, EventArgs e)
        {
            int flag1 = 0;
            int flag2 = 0;
            if (int.TryParse(textBox_TI2.Text, out flag1) && int.TryParse(textBox_TO2.Text, out flag2))
            {
                if (flag2 - flag1 > 0)
                {
                    textBox_TT2.Text = Convert.ToString((flag2 - flag1) * 50000);
                }
            }
        }

        private void textBox_TI2_TextChanged(object sender, EventArgs e)
        {
            int flag1 = 0;
            int flag2 = 0;
            if (int.TryParse(textBox_TI2.Text, out flag1) && int.TryParse(textBox_TO2.Text, out flag2))
            {
                if (flag2 - flag1 > 0)
                {
                    textBox_TT2.Text = Convert.ToString((flag2 - flag1) * 50000);
                }
            }
        }
    }
}
