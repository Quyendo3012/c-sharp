﻿
namespace De1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.cbxChonPhim = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.lbDem = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chọn phim";
            // 
            // cbxChonPhim
            // 
            this.cbxChonPhim.FormattingEnabled = true;
            this.cbxChonPhim.Items.AddRange(new object[] {
            "Cuộc phiêu lưu của chó",
            "Harry Porter",
            "Spiderman",
            "Ironman"});
            this.cbxChonPhim.Location = new System.Drawing.Point(124, 13);
            this.cbxChonPhim.Name = "cbxChonPhim";
            this.cbxChonPhim.Size = new System.Drawing.Size(159, 21);
            this.cbxChonPhim.TabIndex = 1;
            this.cbxChonPhim.Text = "Cuộc phiêu lưu của chó";
            this.cbxChonPhim.SelectedIndexChanged += new System.EventHandler(this.cbxChonPhim_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(213, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Mời bạn chọn ghế trong phòng chiếu phim: ";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Controls.Add(this.button68, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.button69, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.button70, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.button71, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.button72, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.button73, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.button62, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.button63, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.button64, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.button65, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.button66, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.button67, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.button56, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.button57, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.button58, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.button59, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.button60, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.button61, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.button50, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.button51, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button52, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.button53, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.button54, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.button55, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.button44, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.button45, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button46, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.button47, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.button48, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.button49, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.button43, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.button42, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.button41, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.button40, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.button39, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel1.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(40, 78);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(721, 266);
            this.tableLayoutPanel1.TabIndex = 43;
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(193)))));
            this.button68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button68.Location = new System.Drawing.Point(3, 223);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(114, 40);
            this.button68.TabIndex = 35;
            this.button68.Text = "F1";
            this.toolTip1.SetToolTip(this.button68, "45000đ");
            this.button68.UseVisualStyleBackColor = false;
            this.button68.Click += new System.EventHandler(this.button59_Click);
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(193)))));
            this.button69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button69.Location = new System.Drawing.Point(123, 223);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(114, 40);
            this.button69.TabIndex = 34;
            this.button69.Text = "F2";
            this.toolTip1.SetToolTip(this.button69, "45000đ");
            this.button69.UseVisualStyleBackColor = false;
            this.button69.Click += new System.EventHandler(this.button59_Click);
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(193)))));
            this.button70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button70.Location = new System.Drawing.Point(243, 223);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(114, 40);
            this.button70.TabIndex = 33;
            this.button70.Text = "F3";
            this.toolTip1.SetToolTip(this.button70, "45000đ");
            this.button70.UseVisualStyleBackColor = false;
            this.button70.Click += new System.EventHandler(this.button59_Click);
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(193)))));
            this.button71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button71.Location = new System.Drawing.Point(363, 223);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(114, 40);
            this.button71.TabIndex = 32;
            this.button71.Text = "F4";
            this.toolTip1.SetToolTip(this.button71, "45000đ");
            this.button71.UseVisualStyleBackColor = false;
            this.button71.Click += new System.EventHandler(this.button59_Click);
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(193)))));
            this.button72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button72.Location = new System.Drawing.Point(483, 223);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(114, 40);
            this.button72.TabIndex = 31;
            this.button72.Text = "F5";
            this.toolTip1.SetToolTip(this.button72, "45000đ");
            this.button72.UseVisualStyleBackColor = false;
            this.button72.Click += new System.EventHandler(this.button59_Click);
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(193)))));
            this.button73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button73.Location = new System.Drawing.Point(603, 223);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(115, 40);
            this.button73.TabIndex = 30;
            this.button73.Text = "F6";
            this.toolTip1.SetToolTip(this.button73, "45000đ");
            this.button73.UseVisualStyleBackColor = false;
            this.button73.Click += new System.EventHandler(this.button59_Click);
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(198)))), ((int)(((byte)(202)))));
            this.button62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button62.Location = new System.Drawing.Point(3, 179);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(114, 38);
            this.button62.TabIndex = 29;
            this.button62.Text = "E1";
            this.toolTip1.SetToolTip(this.button62, "50000đ");
            this.button62.UseVisualStyleBackColor = false;
            this.button62.Click += new System.EventHandler(this.button59_Click);
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(198)))), ((int)(((byte)(202)))));
            this.button63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button63.Location = new System.Drawing.Point(123, 179);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(114, 38);
            this.button63.TabIndex = 28;
            this.button63.Text = "E2";
            this.toolTip1.SetToolTip(this.button63, "50000đ");
            this.button63.UseVisualStyleBackColor = false;
            this.button63.Click += new System.EventHandler(this.button59_Click);
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(198)))), ((int)(((byte)(202)))));
            this.button64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button64.Location = new System.Drawing.Point(243, 179);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(114, 38);
            this.button64.TabIndex = 27;
            this.button64.Text = "E3";
            this.toolTip1.SetToolTip(this.button64, "50000đ");
            this.button64.UseVisualStyleBackColor = false;
            this.button64.Click += new System.EventHandler(this.button59_Click);
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(198)))), ((int)(((byte)(202)))));
            this.button65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button65.Location = new System.Drawing.Point(363, 179);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(114, 38);
            this.button65.TabIndex = 26;
            this.button65.Text = "E4";
            this.toolTip1.SetToolTip(this.button65, "50000đ");
            this.button65.UseVisualStyleBackColor = false;
            this.button65.Click += new System.EventHandler(this.button59_Click);
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(198)))), ((int)(((byte)(202)))));
            this.button66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button66.Location = new System.Drawing.Point(483, 179);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(114, 38);
            this.button66.TabIndex = 25;
            this.button66.Text = "E5";
            this.toolTip1.SetToolTip(this.button66, "50000đ");
            this.button66.UseVisualStyleBackColor = false;
            this.button66.Click += new System.EventHandler(this.button59_Click);
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(198)))), ((int)(((byte)(202)))));
            this.button67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button67.Location = new System.Drawing.Point(603, 179);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(115, 38);
            this.button67.TabIndex = 24;
            this.button67.Text = "E6";
            this.toolTip1.SetToolTip(this.button67, "50000đ");
            this.button67.UseVisualStyleBackColor = false;
            this.button67.Click += new System.EventHandler(this.button59_Click);
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(190)))), ((int)(((byte)(254)))));
            this.button56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button56.Location = new System.Drawing.Point(3, 135);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(114, 38);
            this.button56.TabIndex = 23;
            this.button56.Text = "D1";
            this.toolTip1.SetToolTip(this.button56, "40000đ");
            this.button56.UseVisualStyleBackColor = false;
            this.button56.Click += new System.EventHandler(this.button59_Click);
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(190)))), ((int)(((byte)(254)))));
            this.button57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button57.Location = new System.Drawing.Point(123, 135);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(114, 38);
            this.button57.TabIndex = 22;
            this.button57.Text = "D2";
            this.toolTip1.SetToolTip(this.button57, "40000đ");
            this.button57.UseVisualStyleBackColor = false;
            this.button57.Click += new System.EventHandler(this.button59_Click);
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(190)))), ((int)(((byte)(254)))));
            this.button58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button58.Location = new System.Drawing.Point(243, 135);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(114, 38);
            this.button58.TabIndex = 21;
            this.button58.Text = "D3";
            this.toolTip1.SetToolTip(this.button58, "40000đ");
            this.button58.UseVisualStyleBackColor = false;
            this.button58.Click += new System.EventHandler(this.button59_Click);
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(190)))), ((int)(((byte)(254)))));
            this.button59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button59.Location = new System.Drawing.Point(363, 135);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(114, 38);
            this.button59.TabIndex = 20;
            this.button59.Text = "D4";
            this.toolTip1.SetToolTip(this.button59, "40000đ");
            this.button59.UseVisualStyleBackColor = false;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(190)))), ((int)(((byte)(254)))));
            this.button60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button60.Location = new System.Drawing.Point(483, 135);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(114, 38);
            this.button60.TabIndex = 19;
            this.button60.Text = "D5";
            this.toolTip1.SetToolTip(this.button60, "40000đ");
            this.button60.UseVisualStyleBackColor = false;
            this.button60.Click += new System.EventHandler(this.button59_Click);
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(190)))), ((int)(((byte)(254)))));
            this.button61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button61.Location = new System.Drawing.Point(603, 135);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(115, 38);
            this.button61.TabIndex = 18;
            this.button61.Text = "D6";
            this.toolTip1.SetToolTip(this.button61, "40000đ");
            this.button61.UseVisualStyleBackColor = false;
            this.button61.Click += new System.EventHandler(this.button59_Click);
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(193)))));
            this.button50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button50.Location = new System.Drawing.Point(3, 91);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(114, 38);
            this.button50.TabIndex = 17;
            this.button50.Text = "C1";
            this.toolTip1.SetToolTip(this.button50, "35000đ");
            this.button50.UseVisualStyleBackColor = false;
            this.button50.Click += new System.EventHandler(this.button59_Click);
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(193)))));
            this.button51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button51.Location = new System.Drawing.Point(123, 91);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(114, 38);
            this.button51.TabIndex = 16;
            this.button51.Text = "C2";
            this.toolTip1.SetToolTip(this.button51, "35000đ");
            this.button51.UseVisualStyleBackColor = false;
            this.button51.Click += new System.EventHandler(this.button59_Click);
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(193)))));
            this.button52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button52.Location = new System.Drawing.Point(243, 91);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(114, 38);
            this.button52.TabIndex = 15;
            this.button52.Text = "C3";
            this.toolTip1.SetToolTip(this.button52, "35000đ");
            this.button52.UseVisualStyleBackColor = false;
            this.button52.Click += new System.EventHandler(this.button59_Click);
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(193)))));
            this.button53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button53.Location = new System.Drawing.Point(363, 91);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(114, 38);
            this.button53.TabIndex = 14;
            this.button53.Text = "C4";
            this.toolTip1.SetToolTip(this.button53, "35000đ");
            this.button53.UseVisualStyleBackColor = false;
            this.button53.Click += new System.EventHandler(this.button59_Click);
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(193)))));
            this.button54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button54.Location = new System.Drawing.Point(483, 91);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(114, 38);
            this.button54.TabIndex = 13;
            this.button54.Text = "C5";
            this.toolTip1.SetToolTip(this.button54, "35000đ");
            this.button54.UseVisualStyleBackColor = false;
            this.button54.Click += new System.EventHandler(this.button59_Click);
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(193)))));
            this.button55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button55.Location = new System.Drawing.Point(603, 91);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(115, 38);
            this.button55.TabIndex = 12;
            this.button55.Text = "C6";
            this.toolTip1.SetToolTip(this.button55, "35000đ");
            this.button55.UseVisualStyleBackColor = false;
            this.button55.Click += new System.EventHandler(this.button59_Click);
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(190)))));
            this.button44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button44.Location = new System.Drawing.Point(3, 47);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(114, 38);
            this.button44.TabIndex = 11;
            this.button44.Text = "B1";
            this.toolTip1.SetToolTip(this.button44, " 30000đ");
            this.button44.UseVisualStyleBackColor = false;
            this.button44.Click += new System.EventHandler(this.button59_Click);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(190)))));
            this.button45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button45.Location = new System.Drawing.Point(123, 47);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(114, 38);
            this.button45.TabIndex = 10;
            this.button45.Text = "B2";
            this.toolTip1.SetToolTip(this.button45, " 30000đ");
            this.button45.UseVisualStyleBackColor = false;
            this.button45.Click += new System.EventHandler(this.button59_Click);
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(190)))));
            this.button46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button46.Location = new System.Drawing.Point(243, 47);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(114, 38);
            this.button46.TabIndex = 9;
            this.button46.Text = "B3";
            this.toolTip1.SetToolTip(this.button46, " 30000đ");
            this.button46.UseVisualStyleBackColor = false;
            this.button46.Click += new System.EventHandler(this.button59_Click);
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(190)))));
            this.button47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button47.Location = new System.Drawing.Point(363, 47);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(114, 38);
            this.button47.TabIndex = 8;
            this.button47.Text = "B4";
            this.toolTip1.SetToolTip(this.button47, " 30000đ");
            this.button47.UseVisualStyleBackColor = false;
            this.button47.Click += new System.EventHandler(this.button59_Click);
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(190)))));
            this.button48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button48.Location = new System.Drawing.Point(483, 47);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(114, 38);
            this.button48.TabIndex = 7;
            this.button48.Text = "B5";
            this.toolTip1.SetToolTip(this.button48, " 30000đ");
            this.button48.UseVisualStyleBackColor = false;
            this.button48.Click += new System.EventHandler(this.button59_Click);
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(190)))));
            this.button49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button49.Location = new System.Drawing.Point(603, 47);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(115, 38);
            this.button49.TabIndex = 6;
            this.button49.Text = "B6";
            this.toolTip1.SetToolTip(this.button49, " 30000đ");
            this.button49.UseVisualStyleBackColor = false;
            this.button49.Click += new System.EventHandler(this.button59_Click);
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.button43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button43.Location = new System.Drawing.Point(603, 3);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(115, 38);
            this.button43.TabIndex = 5;
            this.button43.Text = "A6";
            this.toolTip1.SetToolTip(this.button43, " 25000đ");
            this.button43.UseVisualStyleBackColor = false;
            this.button43.Click += new System.EventHandler(this.button59_Click);
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.button42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button42.Location = new System.Drawing.Point(483, 3);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(114, 38);
            this.button42.TabIndex = 4;
            this.button42.Text = "A5";
            this.toolTip1.SetToolTip(this.button42, " 25000đ");
            this.button42.UseVisualStyleBackColor = false;
            this.button42.Click += new System.EventHandler(this.button59_Click);
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.button41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button41.Location = new System.Drawing.Point(363, 3);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(114, 38);
            this.button41.TabIndex = 3;
            this.button41.Text = "A4";
            this.toolTip1.SetToolTip(this.button41, " 25000đ");
            this.button41.UseVisualStyleBackColor = false;
            this.button41.Click += new System.EventHandler(this.button59_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.button40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button40.Location = new System.Drawing.Point(243, 3);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(114, 38);
            this.button40.TabIndex = 2;
            this.button40.Text = "A3";
            this.toolTip1.SetToolTip(this.button40, " 25000đ");
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Click += new System.EventHandler(this.button59_Click);
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.button39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button39.Location = new System.Drawing.Point(123, 3);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(114, 38);
            this.button39.TabIndex = 1;
            this.button39.Text = "A2";
            this.toolTip1.SetToolTip(this.button39, " 25000đ");
            this.button39.UseVisualStyleBackColor = false;
            this.button39.Click += new System.EventHandler(this.button59_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(3, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 38);
            this.button1.TabIndex = 0;
            this.button1.Text = "A1";
            this.toolTip1.SetToolTip(this.button1, " 25000đ");
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button59_Click);
            // 
            // button37
            // 
            this.button37.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.button37.Location = new System.Drawing.Point(617, 359);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(144, 36);
            this.button37.TabIndex = 42;
            this.button37.Text = "Thanh toán";
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 371);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 40;
            this.label3.Text = "Thành tiền:";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(81, 371);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 41;
            this.label4.Text = "label4";
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ToolTipTitle = "Giá vé của hàng ghế này là:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(259, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(162, 13);
            this.label5.TabIndex = 44;
            this.label5.Text = "Cuộc phiêu lưu của ScooBy-Doo";
            // 
            // lbDem
            // 
            this.lbDem.AutoSize = true;
            this.lbDem.Location = new System.Drawing.Point(337, 371);
            this.lbDem.Name = "lbDem";
            this.lbDem.Size = new System.Drawing.Size(0, 13);
            this.lbDem.TabIndex = 45;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 443);
            this.Controls.Add(this.lbDem);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbxChonPhim);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Chương trình bán vé xem phim";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbxChonPhim;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbDem;
    }
}

